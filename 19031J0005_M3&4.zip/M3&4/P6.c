#include<stdio.h>
void main(){
	long long num;
    int count = 0,sum=0,b=0;
    printf("Enter any number: ");
    scanf("%lld", &num);
    do
    {
        count++;
        b=num%10;
        num /= 10;
        sum=sum+b;
    } while(num != 0);
    printf("Total digits: %d\n", count);
    printf("Sum of Digits: %d",sum);
	getch();
}
