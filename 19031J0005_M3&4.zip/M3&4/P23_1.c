#include<stdio.h>
void main(){
	long n;
	printf("Enter the n value");
	scanf("%ld",&n);
    double i, s = 0.0; 
  for (i = 1; i <= n; i++) {
  
      s = s + 1/i; 
  }  printf("Sum: %lf",s);
	getch();
}
