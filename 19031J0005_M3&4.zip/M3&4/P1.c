#include<stdio.h>
void main(){
	int n,i;
	printf("Enter a number:");
	scanf("%d",&n);
	printf("First %d natural numbers are:\n",n);
	for(i=1;i<=n;i++)
	{
		printf("%d ",i);
	}
	getch();
}
