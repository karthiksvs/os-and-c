#include<stdio.h>
#include<conio.h>
void main(){
	int no, temp, rem, sum,count=0,n;
printf("Enter Armstrong numbers limit n are:\n");
scanf("%d",&n);
for(no=1; no<=n; no++)
{
temp=no;
sum=0;
while(temp>0)
{
rem=temp%10;
sum=sum+(rem*rem*rem);
temp=temp/10;
}
if(no==sum)
{
printf("\n%d", no);
count++;
}
}
printf("%d",count);
getch( );
}
