#include<stdio.h>
void main(){
	int x = 2,n; 
   	printf("Enter the n value");
	scanf("%d",&n);
    double i, total = 1.0; 
    for (i = 1; i <= n; i++) {
        total = total +(pow(x, i) / i); 
    }
    printf("%.2f", total); 
	getch();
}
