#include<stdio.h>
void main(){
	int n;
    char c;
    printf("Enter the binary number: ");
    scanf("%d", &n);
    int decimal = 0, i = 0, rem;
    while(n != 0)
    {
        rem = n%10;   
        n = n/10; 
        decimal += rem*pow(2, i++);
    }
    printf("\n\n\nThe decimal equivalent of %d is  %d\n\n", n, decimal);
	getch();
}
