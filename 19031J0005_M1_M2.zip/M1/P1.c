#include <stdio.h> 
 int main()  
  {
     printf("Name   : S.V.S.Karthik\n"); 
     printf("DOB    : May 01, 1998\n"); 
     printf("Mobile : 7396502930\n"); 
     getch();
     return 0; 
  }
