#include <stdio.h>
#include<conio.h>

void main()
{
	float kmph;             
float miph;             
	printf("Input kilometers per hour: ");
	scanf("%f", &kmph);
	miph = (kmph * 0.6213712);
	printf("%f miles per hour\n", miph);
getch();
	}

