#include<stdio.h>
#include<conio.h>
void main(){
	int a,b;
	printf("Enter values of a and b:\n");
	scanf("%d %d",&a,&b);
	printf("Addition of a=%d and b=%d is %d\n",a,b,a+b);
		printf("subraction of a=%d and b=%d is %d\n",a,b,a-b);
			printf("Multiplication of a=%d and b=%d is %d\n",a,b,a*b);
			if(a!=0 && b!=0){
				printf("division of a=%d and b=%d is %d\n",a,b,a/b);
				}
				else{
					printf("division cannot be performed");
				}
}
