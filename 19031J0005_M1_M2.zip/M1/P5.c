#include<stdio.h>
#include<conio.h>
void main(){
	int a,b,c,d,e;
	printf("Enter values of a, b,c,d,e:\n");
	scanf("%d %d %d %d %d",&a,&b,&c,&d,&e);
	printf("The multiplication sum is %d",(a*b*c*d*e));
	getch();
}

