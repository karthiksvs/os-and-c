#include <stdio.h>
#include<conio.h>
void main() {
   double radius, circumference, area; 
   double pi = 3.14159265;            
   printf("Enter the radius: ");  
   scanf("%lf", &radius);         
   area = radius * radius * pi;
   circumference = 2.0 * radius * pi;
   printf("The radius is %lf.\n", radius);
   printf("The area is %lf.\n", area);
   printf("The circumference is %lf.\n", circumference);
 getch();
}
