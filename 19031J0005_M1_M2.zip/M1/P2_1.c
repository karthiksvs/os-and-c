#include<stdio.h>
void main(){
	int i=0,j=0,n=5;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			printf("* ");
		}
		printf("\n");
	}
	getch();
}
