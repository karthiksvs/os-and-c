#include <stdio.h>
#include<conio.h>
void main() {
	int tot_mins;  
int hrs;       
int mins;      
int MINaHOUR=60;
	printf("Input minutes: ");
	scanf("%d", &tot_mins);
	hrs = (tot_mins / MINaHOUR);
	mins = (tot_mins % MINaHOUR);
	printf("%d Hours, %d Minutes.\n", hrs, mins);
	getch();
}
