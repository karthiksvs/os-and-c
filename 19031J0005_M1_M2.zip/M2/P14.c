#include <stdio.h>
#include <ctype.h> 
#include <string.h> 
void main()
{
    char grd;
    printf("Input the grade :");
    scanf("%c", &grd);
    grd = toupper(grd);
    switch(grd)
    {
    case 'E':
        printf(" Excellent");
        break;
    case 'V':
        printf(" Very Good");
        break;
    case 'G':
        printf(" Good ");
        break;
    case 'A':
       printf(" Average");
        break;
    case 'F':
       printf(" Fails");
        break;
    default :
        printf("Invalid Grade Found. \n");
        break;
    }
    getch();
} 

