#include<stdio.h>
#include<conio.h>
void main()
{
	int num;
    printf("Enter number(0-9): ");
    scanf("%d", &num);
    switch(num)
    {
    	case 0:
    		printf("Zero\n");
    		break;
        case 1: 
            printf("one");
            break;
        case 2: 
            printf("two");
            break;
        case 3: 
            printf("three");
            break;
        case 4: 
            printf("Four");
            break;
        case 5: 
            printf("Five");
            break;
        case 6: 
            printf("Six");
            break;
        case 7: 
            printf("Seven");
            break;
        case 8: 
            printf("Eight");
            break;
        case 9: 
            printf("Nine");
            break;
        default: 
            printf("Invalid input! Please enter number between 0-9");

    }
	getch();
}
