#include<stdio.h>
void main()
{
    int l, u;
    printf("Enter lower limit: ");
    scanf("%d", &l);
    printf("Enter upper limit: ");
    scanf("%d", &u);

    printf("All natural numbers from %d to %d are: ", l, u);
    printNaturalNumbers(l, u);
    getch();
}
void printNaturalNumbers(int l, int u)
{
    if(l > u)
        return;
    
    printf("%d, ", l);
    printNaturalNumbers(l + 1, u);
}
