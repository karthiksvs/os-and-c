#include<stdio.h>
void main(){
	int i,ctr,a=0;
    printf("Input number of terms : ");
    scanf("%d", &ctr);
    a=fun(ctr);
    printf("The cube of %d is %d",ctr,a);
	getch();
}
int fun(int i){
	int a=0;
	 a=(i*i*i);     
    return a; 
}
