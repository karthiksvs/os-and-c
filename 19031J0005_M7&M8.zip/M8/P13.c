#include<stdio.h>
#include<stdlib.h>
int main()
{
	int *transpose,i,j,r,c; 
	printf("\n How many rows and columns in the matrix:- ");
	scanf(" %d %d",&r,&c);
	transpose=(int*)calloc(r*c,sizeof(int));
	printf("\n Enter the elements:- ");
	for(i=0;i<r;i++)
	for(j=0;j<c;j++) 
	{
	scanf("%d",transpose+(i*c+j)*sizeof(int));
	}
	printf("\n The transpose of matrix is:- \n");
	for(i=0;i<c;i++)
	{
	for(j=0;j<r;j++)
		printf("%5d",*(transpose+(j*c+i)*sizeof(int)));
	printf("\n");
	}
	return 0;
}

