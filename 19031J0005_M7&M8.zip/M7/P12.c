#include<stdio.h>
#include <string.h>
void main()
{
    int i, count = 0, pos1, pos2;
    char str[50], key, a[10];
    printf("enter the string\n");
    scanf(" %[^\n]s", str);
    printf("enter character to be searched\n");
    scanf(" %c", &key);
    for (i = 0;i <= strlen(str);i++)
    {
        if (key == str[i])
        {
            count++;
            if (count  == 1)
            {
                pos1 = i;
                pos2 = i;
                printf("%d\n", pos1 + 1);
            }
            else 
            {
                pos2 = i;
            }
        }
    }
    printf("%d\n", pos2 + 1);
}
