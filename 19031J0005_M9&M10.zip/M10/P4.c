#include <stdio.h>
int N; 
struct date
	    {
	    int month;
	    int day; 
	    int year; 
    };	
    
int f(int year, int month)
{
    if (month <= 2)
	    year = year - 1; 
    else
	    year = year; 
    return year; 
}

int g(int month)
{
    if (month <= 2)
	    month = month + 13; 
    else 
	    month = month + 1; 
    return month; 
}

int n(int year, int month, int day)
{
    N = 1461 * f(year, month) / 4 + 153 * g(month) / 5 + day; 
    return N; 
} 

int main(void)
{
    int result; 
    struct date date1, date2; 
    int n(int year, int month, int day); 
    int f(int year, int month);
    int g(int month); 
    printf("Enter a date (mm:dd:yyyy): "); 
    scanf("%i:%i:%i", &date1.month, &date1.day, &date1.year); 
    printf("Enter one more date (mm:dd:yyyy): ");
    scanf("%i:%i:%i", &date2.month, &date2.day, &date2.year); 
    result = n(date2.year, date2.month, date2.day) - n(date1.year,    date1.month, date1.day); 
    printf("The number of days between your two dates is: %i\n", result); 
    return 0; 
}
