#include <math.h>
#include <stdio.h>
struct quad
{
   double a, b, c;
};

int main() {
    double discriminant, root1, root2, realPart, imagPart;
    struct quad s;
    printf("Enter coefficients a, b and c: ");
    scanf("%lf %lf %lf", &s.a, &s.b, &s.c);

    discriminant = s.b * s.b - 4 * s.a * s.c;

    // condition for real and different roots
    if (discriminant > 0) {
        root1 = (-s.b + sqrt(discriminant)) / (2 * s.a);
        root2 = (-s.b - sqrt(discriminant)) / (2 * s.a);
        printf("root1 = %.2lf and root2 = %.2lf", root1, root2);
    }

    // condition for real and equal roots
    else if (discriminant == 0) {
        root1 = root2 = -s.b / (2 * s.a);
        printf("root1 = root2 = %.2lf;", root1);
    }

    // if roots are not real
    else {
        realPart = -s.b / (2 * s.a);
        imagPart = sqrt(-discriminant) / (2 * s.a);
        printf("root1 = %.2lf+%.2lfi and root2 = %.2f-%.2fi", realPart, imagPart, realPart, imagPart);
    }

    return 0;
} 
